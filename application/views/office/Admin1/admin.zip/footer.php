    <div style="clear:both;color:#aaa; padding:20px;">
    	
                        		<center>&copy; 2013, N-gurukul</center>
                              </div>
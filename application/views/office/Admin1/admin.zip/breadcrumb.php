<div class="container-fluid padded">
            <div class="row-fluid">
                <!-- Breadcrumb line -->
                <div id="breadcrumbs">
                    <div class="breadcrumb-button blue">
                        <span class="breadcrumb-label"><i class="icon-home"></i> Home</span>
                        <span class="breadcrumb-arrow"><span></span></span>
                    </div>
                    <div class="breadcrumb-button">
                        <span class="breadcrumb-label">
                        <i class="icon-beaker"></i> UI Lab </span>
                        <span class="breadcrumb-arrow"><span></span></span>
                    </div>
                    <div class="breadcrumb-button">
                        <span class="breadcrumb-label">
                        <i class="icon-info-sign"></i> Icons </span>
                        <span class="breadcrumb-arrow"><span></span></span>
                    </div>
                </div>
            </div>
        </div>